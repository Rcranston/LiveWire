

<?php $__env->startSection('content'); ?>
<html>
    <body>
            <h3>Show City Detail</h3>

    <div class="tile">
    <div class="tile-icon">
        <div class="example-tile-icon">
        <i class="icon icon-file centered"></i>
        </div>
    </div>
  <div class="tile-content">
    <p class="tile-title"><?php echo e($city->name); ?>,<?php echo e($city->state); ?></p>
    <p class="tile-subtitle">Population in 2010: <?php echo e($city->population_2010); ?> <br>
                            Ranked:<?php echo e($city->population_rank); ?> in <?php echo e($city->state); ?> </p>
  </div>
  <div class="tile-action">
    <button class="btn btn-secondary"><a href="<?php echo e(route('cities.index')); ?>"> Back to All Cities</a></button>
  </div>
</div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\CRUD assignement\CSCD327 Crud Assignment\resources\views/cities/show.blade.php ENDPATH**/ ?>