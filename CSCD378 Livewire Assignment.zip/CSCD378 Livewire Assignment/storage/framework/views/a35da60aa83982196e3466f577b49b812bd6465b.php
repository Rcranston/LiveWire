

<?php $__env->startSection('content'); ?>

            <h3>List of Cities</h3>
            <a class="btn btn-primary" href="<?php echo e(route('cities.create')); ?>">Add City</a>
            <table class="table table-striped table-hover">
            
            <thead>
                <tr>
                <th><a href="<?php echo e(route('cities.index','3')); ?>">Rank</a></th>
                <th><a href="<?php echo e(route('cities.index','0')); ?>">City</a></th>
                <th><a href="<?php echo e(route('cities.index','1')); ?>">State</a></th>
                <th><a href="<?php echo e(route('cities.index','2')); ?>">Population</a></th>
                <th></th>
                <th></th>
                <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($city->population_rank); ?></td>
                <td><?php echo e($city->name); ?></td>
                <td><?php echo e($city->state); ?></td>
                <td><?php echo e($city->population_2010); ?></td>
                <td><a href="<?php echo e(route('cities.show',$city->id)); ?>">More Info</a></td>
                <td><a href="<?php echo e(route('cities.edit',$city->id)); ?>"><button class="btn btn-secondary" type="submit">Edit</button></a></td>
                <td><form action="<?php echo e(route('cities.destroy',$city->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you wish to remove?')">
                <?php echo csrf_field(); ?>    
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-error" type="submit">Remove</button>
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\CRUD assignement\CSCD327 Crud Assignment\resources\views/cities/index.blade.php ENDPATH**/ ?>