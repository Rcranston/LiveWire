<?php $__env->startSection('title'); ?>
City App (Livewire Component)
<?php $__env->stopSection(); ?>
<div>

<input wire:model="search" type="text" placeholder=" Search Cities EX. Seattle" size="50" />
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>
                <a href="#" wire:click="doSort('population_rank','asc')">&uarr;</a>
                Rank
                <a href="#" wire:click="doSort('population_rank','desc')">&darr;</a>
            </th>
            <th>
                <a href="#" wire:click="doSort('name','asc')">&uarr;</a>
                City
                <a href="#" wire:click="doSort('name','desc')">&darr;</a>
            </th>
            <th>
                <a href="#" wire:click="doSort('state','asc')">&uarr;</a>
                State
                <a href="#" wire:click="doSort('state','desc')">&darr;</a>
            </th>
            <th>
                <a href="#" wire:click="doSort('population_2010','asc')">&uarr;</a>
                Population
                <a href="#" wire:click="doSort('population_2010','desc')">&darr;</a>
            </th>
        </tr>
    </thead>
        <tbody>
        <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($city->population_rank); ?></td>
                <td><?php echo e($city->name); ?></td>
                <td><?php echo e($city->state); ?></td>
                <td><?php echo e($city->population_2010); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table> 
    
</div>
<?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\LiveWire assignement\CSCD327 Livewire Assignment\resources\views/livewire/city-component.blade.php ENDPATH**/ ?>