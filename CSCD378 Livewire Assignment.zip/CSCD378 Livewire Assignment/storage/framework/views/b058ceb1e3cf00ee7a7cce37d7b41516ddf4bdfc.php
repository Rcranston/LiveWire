<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
        <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
        <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
        <div class="container m-2">
        <h1><?php echo $__env->yieldContent('title'); ?></h1>
            <div Class="mt-1">
            <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\LiveWire assignement\CSCD327 Livewire Assignment\resources\views/layouts/app.blade.php ENDPATH**/ ?>