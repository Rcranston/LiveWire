<!DOCTYPE html>
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
<html>
    <head>
        <title>Cities</title>
    </head>
    <body>
    <div class="bg-dark">
        <h1>Cities App</h1>
    </div>
    <?php if(session()->get('success')): ?>
    <div class="toast toast-succcess">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
        <!--<div class="s-rounded">-->
         <?php echo $__env->yieldContent('content'); ?> 
    <div class="bg-dark">
         <br>
         <br>
    </div> 
    </body>
</html><?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\CRUD assignement\CSCD327 Crud Assignment\resources\views/layout.blade.php ENDPATH**/ ?>