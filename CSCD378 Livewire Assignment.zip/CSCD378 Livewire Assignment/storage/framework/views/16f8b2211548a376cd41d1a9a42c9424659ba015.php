<?php $__env->startSection($section); ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount($component, $componentParameters)->dom;
} elseif ($_instance->childHasBeenRendered('yyylaxE')) {
    $componentId = $_instance->getRenderedChildComponentId('yyylaxE');
    $componentTag = $_instance->getRenderedChildComponentTagName('yyylaxE');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yyylaxE');
} else {
    $response = \Livewire\Livewire::mount($component, $componentParameters);
    $dom = $response->dom;
    $_instance->logRenderedChild('yyylaxE', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ryanc\Google Drive\Classes year 5 2020 Spring\CSCD 378\LiveWire assignement\CSCD327 Livewire Assignment\vendor\livewire\livewire\src\Macros/livewire-view.blade.php ENDPATH**/ ?>