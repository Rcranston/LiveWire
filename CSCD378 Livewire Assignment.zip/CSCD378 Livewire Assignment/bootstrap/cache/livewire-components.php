<?php return array (
  'city-component' => 'App\\Http\\Livewire\\CityComponent',
);